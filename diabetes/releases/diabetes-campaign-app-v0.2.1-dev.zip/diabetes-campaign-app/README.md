# Campaña Diabetes — aplicación PHP/MariaDB

Código fuente PHP/MariaDB para XAMPP o alojamiento compartido compatible. Corte actual: `0.2.1-dev`, corrección incremental sobre `0.2.0-dev`. Las versiones anteriores están preservadas en `releases/`; las fechas de campaña y detalles de IONOS siguen pendientes.

## Cambios en este corte

La farmacia introduce solo su número correlativo. El servidor obtiene su SOE de la farmacia asociada a la sesión, valida `OR-XXX-F` con tres dígitos y compone el identificador visible `SOE-número`; MariaDB conserva solo el número canónico (normaliza ceros iniciales, rechaza cero) y aplica unicidad por campaña/farmacia/número. No se recogen nombres, apellidos ni DNI.

Las observaciones se persisten como incidencias informativas separadas de las advertencias y no bloquean el registro. Las campañas activas vencidas pasan a `closed` y la transición se audita. Los cálculos incluyen `is_current`: correcciones dejan los anteriores como históricos sin borrarlos, y el listado solo presenta resultados vigentes.

No se modificaron las reglas FINDRISC/MEDAS ni las tres cuestiones del cuestionario aún pendientes de decisión. El detalle se encuentra en `docs/cambios-0.2.1-dev.md`.

## Instalación y actualización

Para una base nueva, importa `database/schema.sql`. Desde v0.2.0-dev, respalda la base y ejecuta una vez `database/migrations/003_current_calculation_marker.sql`. Desde v0.1.0-dev, ejecuta las migraciones 002 y 003, en ese orden. Consulta `docs/instalacion-desarrollo.md`.

No uses datos reales hasta probar código y persistencia en XAMPP/MariaDB. Este corte es desarrollo, no producción.
