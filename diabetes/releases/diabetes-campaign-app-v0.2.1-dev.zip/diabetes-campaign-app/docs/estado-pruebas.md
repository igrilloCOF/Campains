# Estado de pruebas y requisitos

Actualizado: 5 de noviembre de 2026, corte `0.2.1-dev`.

## Verificaciones ejecutadas

Se realizaron comprobaciones estáticas con Python sobre los archivos del proyecto: formato SOE y número correlativo, restricción única por campaña/farmacia/número, existencia de la persistencia de incidencias `validation_observation`, cambio server-side del estado vencido, marca `is_current` en esquema y consulta de listado, y lógica de la migración 003 que clasifica el cálculo de mayor `id` como vigente. Se comprobó la presencia de la nueva migración y documentos en el ZIP, sin `.env` real.

Son revisiones estáticas del código fuente, no pruebas de las rutas PHP ni de la persistencia real. No se modificaron las reglas FINDRISC/MEDAS ni las decisiones pendientes: unidad de glucosa, intervalos de tabaco y coherencia con «Paciente masculino» en diabetes gestacional.

## Pruebas no ejecutadas

No hay PHP CLI, `mariadbd` ni `mysqld` disponible. No se ejecutaron `php -l`, `php tests/scoring_test.php`, migración SQL, inserción/lectura real de incidencias, cierre de campaña, ni corrección que conserva cálculos. No se afirma que el código o la migración hayan pasado pruebas de ejecución.

## Verificación pendiente en XAMPP/MariaDB

Aplicar la migración 003 en una copia de v0.2.0 y confirmar que no elimina cálculos y que selecciona como vigente el último por registro/escala. Probar SOE válido e inválido; comprobar que la interfaz solo solicita el número y persiste ese número sin nombre u otros identificadores; probar duplicados dentro de campaña/farmacia y reutilización en otra. Guardar una observación y comprobar que crea una incidencia informativa sin impedir la alta. Vencer una campaña y confirmar el estado `closed` y la entrada de auditoría. Corregir un registro y comprobar que los resultados anteriores quedan `is_current=0`, los nuevos quedan `is_current=1` y el listado muestra solo los vigentes.

El panel de administración completo y exportaciones siguen fuera de este corte. No utilizar datos reales de salud hasta completar pruebas de integración, seguridad y protección de datos.
