# Instalación de desarrollo

## Requisitos

PHP 8.1 o superior con PDO y pdo_mysql, MariaDB compatible con InnoDB/JSON y Apache. Las versiones de XAMPP/IONOS deben confirmarse; este corte no se ha probado aún en ellas.

## Instalación nueva

1. Crear una base MariaDB y un usuario SQL exclusivo.
2. Importar `database/schema.sql` de este corte.
3. Configurar `.env` fuera del document root, completar credenciales y generar una `APP_KEY` privada de al menos 32 caracteres. Usar `SESSION_SECURE=false` solo en HTTP local; con datos, HTTPS y `SESSION_SECURE=true`.
4. Crear administrador con `php bin/create-admin.php admin` y sembrar la campaña de preparación con `php bin/seed-campaign.php`.
5. Configurar `public/` como document root y validar con datos ficticios.

Las farmacias deben tener SOE de formato `OR-` + tres dígitos + `-F`. El formulario pide solo un número correlativo de hasta 64 dígitos y mayor que cero. El servidor normaliza ceros iniciales para evitar que `01` y `1` se conviertan en identificadores distintos. Se muestra como `SOE-número` pero se almacena únicamente el número. No introducir nombres, apellidos, DNI ni otros datos identificativos.

## Actualización

Realizar backup completo. Desde v0.2.0-dev, ejecutar una sola vez `database/migrations/003_current_calculation_marker.sql`. La migración mantiene todos los cálculos y marca vigente el de mayor `id` por registro/escala. Desde v0.1.0-dev, ejecutar primero la migración 002 y luego la 003. Los DDL de MariaDB pueden confirmar cambios automáticamente; si una migración falla, inspeccionar la base antes de reintentar.

## Campañas y puntuaciones

Al recibir una petición, el servidor cambia a `closed` las campañas `active` cuyo fin ya pasó, y registra la transición en auditoría. Es un cierre diferido por petición: sin tráfico después de la fecha, el estado se actualiza al llegar la siguiente solicitud. La escritura comprueba nuevamente el estado y las fechas en MariaDB.

Los listados consultan `record_calculations.is_current=1`; para trazabilidad, las filas históricas quedan con `is_current=0`. Al corregir un registro, la actualización de marcas y las nuevas puntuaciones quedan dentro de la misma transacción.

## Pruebas

Con PHP CLI, ejecutar `php -l public/index.php` y `php tests/scoring_test.php`. En XAMPP/MariaDB también hay que probar la migración, unicidad entre campaña/farmacia, observaciones no bloqueantes, cierre/auditoría y corrección con preservación de cálculos históricos. No se han ejecutado pruebas PHP ni MariaDB en este entorno.
