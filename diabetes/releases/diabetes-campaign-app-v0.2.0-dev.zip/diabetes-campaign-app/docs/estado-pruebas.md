# Estado de pruebas y requisitos

Fecha de actualización: 3 de noviembre de 2026, corte 0.2.0-dev.

## Comprobaciones realizadas en este entorno

Se comprobó la lectura estática de la estructura y dependencias entre cuestionario, reglas, autenticación, controlador y esquema. Se parsearon los archivos JSON de configuración y se comprobó que contienen 34 preguntas numeradas, campos adicionales de sexo/TSI y 14 reglas MEDAS. Se revisó que la prueba no utilice valores decimales como claves asociativas.

## Pruebas no ejecutadas

Este entorno no tiene PHP CLI, `mariadbd` ni `mysqld`. Por ello no se ejecutaron `php -l`, `php tests/scoring_test.php`, comandos CLI, importación del esquema, migración SQL ni pruebas de integración HTTP. No se afirma que el código haya pasado pruebas de ejecución.

## Limitaciones funcionales conocidas

El panel de administración integral sigue pendiente: creación guiada de campañas y versiones, edición de cuestionario/reglas, validación previa a activación, incidencias administrativas, invalidación de registros, importación revisada de farmacias y exportaciones/diccionario. El esquema prepara versionado, revisiones, estados e incidencias, pero las interfaces de administración aún no las operan.

Los rangos numéricos fuera de lo estructural solo generan bloqueos/advertencias/observaciones si se configuran por pregunta. No se inventan límites clínicos. La invalidación lógica conserva filas y unicidad, pero no hay ruta para ejecutarla. No se añadieron triggers de inmutabilidad; es una protección por implementar y probar antes de producción.

No desplegar públicamente ni almacenar información real de salud hasta ejecutar pruebas de PHP/MariaDB, completar el panel y hacer revisión de seguridad y protección de datos.
