# Instalación de desarrollo

## Requisitos

PHP 8.1 o superior con PDO y pdo_mysql, MariaDB compatible con InnoDB y JSON, y Apache. Las versiones disponibles en XAMPP/IONOS deben confirmarse antes del despliegue; no se ha probado todavía con esas distribuciones.

## Instalación nueva

1. Crear una base MariaDB y un usuario SQL exclusivo para ella.
2. Importar `database/schema.sql`.
3. Copiar `.env.example` a `.env` en la raíz, fuera del document root; completar la conexión y crear una `APP_KEY` aleatoria de al menos 32 caracteres. Configurar `SESSION_SECURE=false` solo para desarrollo HTTP local; en cualquier entorno con datos, usar HTTPS y `SESSION_SECURE=true`.
4. Ejecutar `php bin/create-admin.php admin` desde la raíz; el script pide una contraseña de al menos 14 caracteres y solo puede ejecutarse por CLI.
5. Ejecutar `php bin/seed-campaign.php`. Este inserta una campaña en preparación, versión 1, con preguntas y reglas en MariaDB. Los archivos JSON son plantillas de siembra; el servicio web consulta MariaDB.
6. Configurar el document root en `public/`, habilitar HTTPS y realizar pruebas antes de cargar datos.

La campaña se crea sin fechas y en preparación. No se admitirán altas hasta configurar y activar una campaña. No se deben introducir datos reales de pacientes durante pruebas.

## Actualización desde el corte 0.1.0-dev

Hacer copia de seguridad completa de la base y los archivos. Ejecutar una sola vez `database/migrations/002_configuration_history_security.sql` sobre la base anterior. Esta migración asocia cuestionario, reglas y registros existentes con la versión de configuración actual. Los DDL de MariaDB pueden confirmar cambios automáticamente; si el script falla, inspeccionar la base antes de reintentar. Consultar además `docs/cambios-0.2.0-dev.md`.

## Pruebas

Cuando PHP CLI esté instalado, ejecutar desde la raíz `php tests/scoring_test.php`. Esa prueba no requiere base de datos. Las rutas, autenticación, migración y transacciones necesitan ejecutarse por separado con una instalación MariaDB. Ninguna de esas pruebas se ha podido ejecutar en este entorno.
