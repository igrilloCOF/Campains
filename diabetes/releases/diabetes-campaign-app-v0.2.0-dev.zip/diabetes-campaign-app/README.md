# Campaña Diabetes — aplicación PHP/MariaDB

Código fuente convencional para PHP 8.1+ y MariaDB, pensado para XAMPP y alojamiento compartido compatible. No utiliza almacenamiento ni backend de Manus. Las fechas definitivas de campaña y las versiones del alojamiento IONOS siguen pendientes de confirmar.

## Versión

Corte actual: `0.2.0-dev`. El primer corte quedó archivado como `releases/diabetes-campaign-app-v0.1.0.zip`. Los cambios y límites de esta fase están en `docs/cambios-0.2.0-dev.md`.

## Estado del proyecto

Este es un corte inicial de desarrollo, no una versión de producción. Tiene el esquema relacional versionado, autenticación básica, formularios de farmacia, reglas de cálculo parametrizadas y estructura de revisiones. El panel administrativo completo, importación revisada, exportaciones, invalidación desde interfaz y varias pruebas de seguridad aún faltan. No registrar información sanitaria real.

## Instalación

La guía está en `docs/instalacion-desarrollo.md`. Para una base nueva importa `database/schema.sql`. Para actualizar una base del primer corte v0.1.0, primero haz una copia de seguridad y ejecuta una sola vez `database/migrations/002_configuration_history_security.sql`.

Usa `.env.example` como plantilla fuera del document root. No subas `.env` real al repositorio ni expongas `storage/`, los SQL o los comandos CLI en producción.

## Cuestionario y reglas

La aplicación en ejecución lee las preguntas de MariaDB usando campaña y versión de configuración. `config/questionnaire.json` y `config/scoring.example.json` solo sirven como plantillas del comando inicial de siembra. Cada registro conserva la versión usada, las respuestas originales se separan de los cálculos, y la corrección conserva una revisión previa.

Las decisiones aprobadas están documentadas en `docs/criterios-aprobados.md`; una copia legible de preguntas y opciones está en `docs/cuestionario-revisado.md`.

## Pruebas

El estado real está en `docs/estado-pruebas.md`. El entorno de desarrollo actual no tiene PHP CLI ni servidor MariaDB; solo se hicieron comprobaciones estáticas del código/JSON. No se han ejecutado pruebas PHP ni migraciones.
