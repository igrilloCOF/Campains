# Instalación de desarrollo

## Requisitos

- PHP 8.1+ con extensiones PDO y pdo_mysql.
- MariaDB compatible con InnoDB y JSON.
- Apache con `mod_rewrite` o acceso directo a `public/index.php`.

Las versiones concretas del alojamiento IONOS siguen pendientes de confirmar. No se ha probado en XAMPP ni en IONOS.

## Inicio local

1. Crear una base vacía y un usuario SQL exclusivo para la aplicación.
2. Importar `database/schema.sql` con el cliente MariaDB/MySQL.
3. Copiar `.env.example` a `.env` en el directorio raíz, completar credenciales y generar una clave propia aleatoria. No alojar `.env` bajo el document root.
4. Ejecutar `php bin/create-admin.php admin` desde la raíz para crear la cuenta inicial.
5. Ejecutar `php bin/seed-campaign.php` para cargar campaña en preparación, preguntas aprobadas, TSI inicial y reglas de ejemplo.
6. Configurar Apache para que el document root sea `public/`; habilitar TLS en todo entorno con datos.

La campaña se crea sin fechas y en preparación. No se deben introducir registros de prueba con datos reales. La preparación de la campaña no activa el formulario.

## Limitación importante

El código de interfaz y panel administrativo es un corte de desarrollo. El alta/corrección de registros no debe considerarse terminado hasta completar todos los puntos de `estado-pruebas.md` y las pruebas reales. No desplegar públicamente para datos sanitarios en este estado.
