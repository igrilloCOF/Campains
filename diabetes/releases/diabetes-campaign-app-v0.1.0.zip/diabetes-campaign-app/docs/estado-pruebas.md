# Estado de pruebas y requisitos

Fecha de elaboración: 3 de noviembre de 2026.

## Pruebas ejecutadas

- Revisión del contenido adjunto y transcripción del cuestionario aprobado: realizada.
- Revisión manual del esquema, de la estructura de los códigos de respuestas y de reglas de puntuación: parcial.
- Disponibilidad de PHP CLI en este entorno: comprobada y no disponible. No se ejecutó php -l ni pruebas PHP.
- MariaDB Server: no disponible; solo está presente el cliente MySQL. No se ejecutaron migraciones ni pruebas de integración.
- Pruebas de aceptación funcional y de seguridad: no ejecutadas.

## Pendiente obligatorio antes de datos reales

1. Completar panel de administración para campañas, cuestionario, reglas, farmacias, importación revisada, TSI, consulta de registros, auditoría, exportación CSV/XLSX y diccionario.
2. Completar cambio obligatorio de contraseña y control real del primer acceso.
3. Guardar cuestionario/reglas por versión en la base de datos y asegurar inmutabilidad al activar; no basta el archivo JSON de desarrollo.
4. Diseñar y probar historial diferencial de cambios al corregir una respuesta.
5. Completar validación de rangos y coherencia clínica aprobados (sin inventar rangos); no se permite activar con reglas incompletas.
6. Verificar protección contra CSRF en todas las acciones, autorización directa, secuestro de sesión, enumeración, acceso entre farmacias y carga de archivos maliciosos.
7. Probar la unicidad concurrente (dos envíos simultáneos), transacciones, conservación de respuestas, pacientes con diabetes, casos límite y versiones históricas.
8. Ejecutar pruebas de compatibilidad con PHP 8.1+ y MariaDB de las versiones reales de XAMPP/IONOS.
9. Revisar endurecimiento de instalación, HTTPS, copia/restauración y obligaciones de protección de datos con responsables.

El proyecto no debe utilizarse para guardar datos sanitarios hasta que estas pruebas se hayan ejecutado y el responsable apruebe la configuración clínica.
