# Campaña Diabetes — aplicación PHP/MariaDB

Código fuente convencional, pensado para PHP 8.1+ y MariaDB en XAMPP y alojamiento compartido compatible. No utiliza almacenamiento ni backend de Manus. Las fechas de campaña y los datos del alojamiento son configuración pendiente y no se presuponen.

## Estado

Este repositorio es una base de implementación en curso. Antes de considerarlo apto para datos reales deben estar terminados y probados todos los requisitos del pliego: paneles completos, autorización servidor, auditoría, importación revisada de farmacias, exportaciones CSV/XLSX, configuración guiada del cuestionario y reglas, protección de configuración activada, pruebas de aceptación, revisión de seguridad y documentación definitiva. No se deben introducir datos reales de salud hasta superar esa verificación.

## Instalación prevista

1. Crear una base de datos MariaDB y un usuario con permisos limitados a esa base.
2. Importar `database/schema.sql`.
3. Copiar `.env.example` a `.env` fuera del directorio público, generar una clave aleatoria y completar las credenciales.
4. Apuntar el document root del servidor a `public/` y habilitar HTTPS.
5. Crear la cuenta de administración mediante un comando de instalación de un solo uso (pendiente de completar), y deshabilitar/eliminar dicho instalador inmediatamente.

No se incluyen credenciales reales. No subir `.env` al repositorio ni exponer `storage/` o los archivos SQL públicamente.

## Reglas aprobadas por el organizador

- Mantener las preguntas originales salvo la pregunta de actividad física (Sí/No, al menos 30 minutos diarios) y la pregunta de repostería MEDAS (menos de 3 / 3 o más por semana).
- Añadir sexo biológico Hombre/Mujer y TSI textual, inicialmente `001`–`006`.
- FINDRISC: factores y umbrales aprobados en `docs/criterios-aprobados.md` (pendiente de volcar al configurador gráfico). Si diabetes actual = Sí, FINDRISC no aplicable; MEDAS sí se calcula.
- MEDAS: 14 ítems, cada uno de 0/1, interpretación acordada <9 baja, ≥9 buena adherencia.
- Respuestas originales separadas de puntuaciones; nunca recalcular en silencio registros históricos.

## Pruebas

Las pruebas de aceptación están pendientes. El entorno de desarrollo inicial no incluye PHP CLI ni MariaDB; no se afirma que este código haya sido ejecutado allí. Antes de desplegar, validar con las versiones reales de XAMPP e IONOS.
