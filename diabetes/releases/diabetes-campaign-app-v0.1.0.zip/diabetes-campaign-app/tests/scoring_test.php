<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
use App\Services\ScoringService;
$cfg=json_decode((string)file_get_contents(dirname(__DIR__).'/config/scoring.example.json'),true,512,JSON_THROW_ON_ERROR);$s=new ScoringService();
$base=['diabetes_actual'=>'no','edad'=>'45','peso_kg'=>'75','altura_m'=>'1.5811','cintura_cm'=>'94','sexo'=>'hombre','actividad_fisica'=>'si','fruta_verdura_diaria'=>'diario','hipertension_medicacion'=>'no','hiperglucemia_previa'=>'no','antecedentes_familiares'=>'ninguno'];
$r=$s->calculateFindrisc($base,$cfg['findrisc']);assert($r['items']['age']===2);assert($r['items']['waist']===3);assert($r['items']['bmi']===3);assert($r['status']==='calculated');
foreach([44=>0,45=>2,54=>2,55=>3,64=>3,65=>4] as $age=>$expected){$x=$base;$x['edad']=(string)$age;$r=$s->calculateFindrisc($x,$cfg['findrisc']);assert($r['items']['age']===$expected,"age boundary {$age}");}
foreach([93.99=>0,94=>3,102=>3,102.01=>4] as $waist=>$expected){$x=$base;$x['cintura_cm']=(string)$waist;$r=$s->calculateFindrisc($x,$cfg['findrisc']);assert($r['items']['waist']===$expected,"waist boundary {$waist}");}
foreach([24.9=>0,25=>1,29.9=>1,30=>3] as $bmi=>$expected){$x=$base;$x['peso_kg']=(string)$bmi;$x['altura_m']='1';$r=$s->calculateFindrisc($x,$cfg['findrisc']);assert($r['items']['bmi']===$expected,"BMI boundary {$bmi}");}
$base['diabetes_actual']='si';$r=$s->calculateFindrisc($base,$cfg['findrisc']);assert($r['status']==='not_applicable'&&$r['total']===null);
$medas=[];for($i=1;$i<=14;$i++)$medas[sprintf('medas_%02d',$i)]='si';$r=$s->calculateMedas($medas,$cfg['medas']);assert($r['total']===14&&$r['interpretation']==='Buena adherencia a la dieta mediterránea');
$medas['medas_14']='no';$medas['medas_13']='no';$medas['medas_12']='no';$medas['medas_11']='no';$medas['medas_10']='no';$r=$s->calculateMedas($medas,$cfg['medas']);assert($r['total']===9&&$r['interpretation']==='Buena adherencia a la dieta mediterránea');
$medas['medas_09']='no';$r=$s->calculateMedas($medas,$cfg['medas']);assert($r['total']===8&&$r['interpretation']==='Baja adherencia a la dieta mediterránea');
echo "Pruebas básicas de puntuación superadas.\n";
