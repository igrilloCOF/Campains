<?php
declare(strict_types=1);
namespace App\Services;
use DomainException;
final class ValidationException extends DomainException { public function __construct(public readonly array $errors){parent::__construct('Revisa los campos indicados.');} }
