<?php
declare(strict_types=1);
namespace App\Services;
use App\Core\Database;
use PDO;
final class AuthService {
 public function login(string $username,string $password): bool {
  $db=Database::connection();
  $q=$db->prepare("SELECT u.id,u.username,u.role,u.pharmacy_id,u.password_hash,u.enabled,u.must_change_password,p.enabled AS pharmacy_enabled FROM users u LEFT JOIN pharmacies p ON p.id=u.pharmacy_id WHERE u.username=:u LIMIT 1");
  $q->execute(['u'=>$username]); $row=$q->fetch();
  $ok=$row && (int)$row['enabled']===1 && ($row['role']!=='pharmacy'||(int)$row['pharmacy_enabled']===1) && password_verify($password,$row['password_hash']);
  if(!$ok){$this->audit($row['id']??null,'login','user',$row['id']??null,'failure');return false;}
  session_regenerate_id(true);
  $_SESSION['user']=['id'=>(int)$row['id'],'username'=>$row['username'],'role'=>$row['role'],'pharmacy_id'=>$row['pharmacy_id']?(int)$row['pharmacy_id']:null,'must_change_password'=>(bool)$row['must_change_password']];
  $this->audit((int)$row['id'],'login','user',(int)$row['id'],'success'); return true;
 }
 public function logout(): void { $u=$_SESSION['user']??null; if($u)$this->audit($u['id'],'logout','user',$u['id'],'success'); $_SESSION=[]; if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain']??'',(bool)$p['secure'],(bool)$p['httponly']);} session_destroy(); }
 private function audit(?int $user,string $action,string $type,mixed $id,string $result): void { try {$s=Database::connection()->prepare('INSERT INTO audit_log(user_id,action,entity_type,entity_id,result,ip_address) VALUES(?,?,?,?,?,?)');$s->execute([$user,$action,$type,$id===null?null:(string)$id,$result,substr((string)($_SERVER['REMOTE_ADDR']??''),0,45)]);}catch(\Throwable $e){error_log('Audit write failed: '.$e->getMessage());} }
}
