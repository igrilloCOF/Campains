<?php
declare(strict_types=1);
namespace App\Services;
use App\Core\Database;
use DomainException;
final class QuestionnaireService {
 public function questions(): array { $p=dirname(__DIR__,2).'/config/questionnaire.json'; $d=json_decode((string)file_get_contents($p),true,512,JSON_THROW_ON_ERROR); return $d['questions']; }
 public function validate(array $input): array {
  $out=[]; $errors=[];
  foreach($this->questions() as $q){$code=$q['code'];$value=trim((string)($input[$code]??''));
   if($value===''){ $errors[$code]='Este campo es obligatorio.'; continue; }
   if(($q['type']??'')==='single_choice'){
    if(($q['options_source']??'')==='tsi_categories') { $ts=Database::connection()->prepare('SELECT 1 FROM tsi_categories WHERE code=? AND enabled=1');$ts->execute([$value]);if(!$ts->fetchColumn()) $errors[$code]='Selecciona una categoría TSI habilitada.'; }
    elseif(!array_key_exists($value,$q['options']??[])) $errors[$code]='Selecciona una opción válida.';
   } elseif(in_array($q['type'],['integer','decimal'],true)) {
    $n=str_replace(',','.',$value); if(!is_numeric($n)) $errors[$code]='Introduce un valor numérico válido.';
    elseif(($q['type']==='integer' && filter_var($value,FILTER_VALIDATE_INT)===false)) $errors[$code]='Introduce un número entero.';
    elseif((float)$n<0) $errors[$code]='El valor no puede ser negativo.';
   }
   $out[$code]=$value;
  }
  if($errors) throw new ValidationException($errors);
  return $out;
 }
}
